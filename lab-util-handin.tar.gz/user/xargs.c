#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include  "kernel/param.h"

#define MAXSIZE 1024

int
main(int argc, char *argv[])
{
   char * params[MAXARG];
   char line[MAXSIZE];
   int args_idx=0;
   int n;
   if(argc<1){
       fprintf(2,"usage: xargs <command> ...");
   }
   char * cmd=argv[1];
   for(int i=1;i<argc;i++){
       params[args_idx++]=argv[i];
   }
   char * arg=(char*)malloc(sizeof(line));
   int arg_index=0;
   while((n=read(0,line,MAXSIZE))>0){
      for(int i=0;i<n;i++){
          if(line[i]==' ' || line[i]=='\n'){
              arg[arg_index]=0;
              params[args_idx++]=arg;
              arg_index=0;
              arg=(char*)malloc(sizeof(line));
          }else{
              arg[arg_index++]=line[i];
          }
      }
      
   }
   
   if(fork()==0){
       exec(cmd,params);
       exit(0);
       
   }else{
       wait(0);
       exit(0);
   }
   
  
}