
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"



void sieve(int*p);

int
main(int argc, char *argv[])
{
   
   int p[2];
   pipe(p);
   if(fork()==0){
       sieve(p);       
   }else{
      close(p[0]);
      for(int i=2;i<=35;i++){
          write(p[1],&i,sizeof(int));
      }
      close(p[1]);
      wait((int*)0);
   }
   exit(0);

   
}

void sieve(int*p){
    int child[2];
    pipe(child);
    int n;
    close(p[1]);
    if((read(p[0],&n,sizeof(int)))==0 || n==0){
        exit(0);
    }
    if(fork()==0){
        sieve(child); 
    }else{
       
        close(child[0]);
        int prime=n;
        printf("prime %d\n",prime);
        while((read(p[0],&n,sizeof(int)))!=0){
            if(n%prime!=0){
                write(child[1],&n,sizeof(int));
            }
        }
        close(child[1]);
        wait((int*)0);
        exit(0);
    }
    
}



